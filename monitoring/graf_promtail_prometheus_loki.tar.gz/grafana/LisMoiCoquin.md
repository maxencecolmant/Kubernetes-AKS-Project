kubectl create namespace monitoring

#Ajout des 2 repos helm

	helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
	helm repo add grafana https://grafana.github.io/helm-charts

#Installation avec Helm

helm upgrade --install prometheus -f prometheus.yml prometheus-community/prometheus -n monitoring
helm upgrade --install loki -f grafana_loki.yaml grafana/loki  -n monitoring
helm upgrade --install promtail -f grafana_promtail.yaml grafana/promtail  -n monitoring

Quand les 3 sont biens lancés :

helm upgrade --install grafana -f values.yaml grafana/grafana  -n monitoring


La suite dans la noche



